# Assinatura persistente do Rota Fácil Pro

Para permitir atualizações por cima da versão anterior, o APK precisa usar sempre a mesma chave de assinatura.

O workflow usa estes Secrets do GitHub:
- ROTA_KEYSTORE_BASE64
- ROTA_KEYSTORE_PASSWORD
- ROTA_KEY_ALIAS
- ROTA_KEY_PASSWORD

A chave deve ser criada uma única vez e mantida em segredo. Para o ambiente de teste desta versão, use uma chave privada criada separadamente; não publique o arquivo `.jks` no repositório.

Depois de configurar os Secrets, o workflow pode gerar o APK assinado sempre com a mesma chave.
