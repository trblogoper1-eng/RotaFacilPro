# Rota Fácil Pro — Android

Base Android nativa em WebView segura, usando o Rota Fácil Pro v17 como conteúdo.

## O que já está preparado
- Aplicativo Android com nome/ícone Rota Fácil Pro
- Tela cheia para o site dentro do app
- JavaScript e armazenamento local
- Câmera para o OCR do manifesto/endereço
- Permissões de localização/GPS
- Links do Google Maps, Waze e Apple Maps enviados para aplicativos externos quando disponíveis
- Conteúdo web servido pelo WebViewAssetLoader (`https://appassets.androidplatform.net/...`)

## Abrir no Android Studio
1. Abra esta pasta como projeto.
2. Aguarde o Gradle sincronizar.
3. Use um aparelho Android ou emulador.
4. Rode o módulo `app`.

## Gerar APK
No Android Studio: Build → Generate App Bundles or APKs → Generate APKs.

## Próxima etapa de produto
O teste grátis de 24h e a assinatura precisam de autenticação + backend + Google Play Billing para que o bloqueio não possa ser burlado apagando dados do aplicativo. Esta versão deixa o aplicativo Android pronto para essa integração sem fingir que o pagamento já está seguro.
