# Rota Fácil Pro - rules intentionally minimal for the first Android build.
